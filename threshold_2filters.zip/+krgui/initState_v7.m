function app = initState_v7(sig, fs, opts, meta)
%INITSTATE_V7 Initialize analysis + detection + candidate pool. No UI here.
% Auto-start threshold: baseline initThrAboveNoise_dB + optional bump to satisfy min IPI.

rear  = sig(:,1);
Nsamp = size(sig,1);

% Rear-only bandpass for detection envelope
xBP = kr.bandpass3(rear, fs, opts.bpHz);

% Envelope in amplitude (Hilbert) + smoothing
env = abs(hilbert(xBP));
env = movmean(env, max(1, round((opts.envSmooth_ms/1000)*fs)));
env_dB = 20*log10(env + eps);

% Robust noise floor in dB (used as reference)
noiseFloor_dB = median(env_dB);

% -------------------------------------------------------
% Initial detection ONCE (defines candidate bounds)
% -------------------------------------------------------
thrDetect = opts.initThrAboveNoise_dB;
[cOn, cOff] = kr.detectCalls_dB(env_dB, fs, noiseFloor_dB, thrDetect, opts);
[cOn, cOff] = krgui.scrubBounds_v7(cOn, cOff, Nsamp);

% Optional: refine bounds to main burst to trim echoes
if isfield(opts,'boundRefine_enable') && opts.boundRefine_enable && ~isempty(cOn)
    for k = 1:numel(cOn)
        [cOn(k), cOff(k)] = krgui.refineBoundsMainBurst_v7(env_dB, fs, cOn(k), cOff(k), opts);
    end
    [cOn, cOff] = krgui.scrubBounds_v7(cOn, cOff, Nsamp);
end

% -------------------------------------------------------
% Auto-start threshold (ADDITIVE constraint)
% Start at baseline initThrAboveNoise_dB; only increase if needed.
% -------------------------------------------------------
thrStart = opts.initThrAboveNoise_dB;

if isfield(opts,'autoThr_enable') && opts.autoThr_enable && numel(cOn) >= 2
    thrStart = bumpThresholdToSatisfyMinIPI(env_dB, noiseFloor_dB, fs, cOn, cOff, opts, thrStart);
end

% -------------------------------------------------------
% State
% -------------------------------------------------------
state = struct();
state.thrAboveNoise_dB = thrStart;

state.calls_on_fixed  = cOn;
state.calls_off_fixed = cOff;

state.manualKeep_fixed = false(numel(cOn),1);

state.autoKeep_fixed = krgui.computeAutoKeepMask_v7(env_dB, noiseFloor_dB, thrStart, cOn, cOff);

[state.calls_on, state.calls_off, state.dispToFixed] = krgui.applyFilter_v7(state);

state.selectedIdx = min(1, max(1, numel(state.calls_on)));
state.mode = "none";
state.accepted = false;

app = struct();
app.sig = sig;
app.fs = fs;
app.opts = opts;
app.meta = meta;
app.rear = rear;
app.env_dB = env_dB;
app.noiseFloor_dB = noiseFloor_dB;
app.Nsamp = Nsamp;
app.state = state;
end

% =====================================================================
% Local helper: bump threshold upward until min IPI constraint satisfied
% =====================================================================
function thrOut = bumpThresholdToSatisfyMinIPI(env_dB, noiseFloor_dB, fs, cOn, cOff, opts, thrBaseline)

minIPI = opts.autoThr_minIPI_ms;
thrMax = opts.autoThr_searchMax_dB;
step   = opts.autoThr_step_dB;

% Start at baseline (preserve your good default)
thrOut = thrBaseline;

% If baseline already satisfies, keep it
if satisfiesMinIPI(env_dB, noiseFloor_dB, fs, cOn, cOff, thrOut, minIPI)
    return;
end

% Otherwise, increase until satisfied or max reached
for thr = thrBaseline:step:thrMax
    if satisfiesMinIPI(env_dB, noiseFloor_dB, fs, cOn, cOff, thr, minIPI)
        thrOut = thr;
        return;
    end
end

% If nothing satisfies, fall back to max
thrOut = thrMax;
end

function ok = satisfiesMinIPI(env_dB, noiseFloor_dB, fs, cOn, cOff, thrAboveNoise_dB, minIPI_ms)
autoKeep = krgui.computeAutoKeepMask_v7(env_dB, noiseFloor_dB, thrAboveNoise_dB, cOn, cOff);
onKept = cOn(autoKeep);

if numel(onKept) < 2
    ok = true; % not enough calls to violate min IPI
    return;
end

ipi_ms = diff(onKept) / fs * 1000;
ok = all(ipi_ms >= minIPI_ms);
end