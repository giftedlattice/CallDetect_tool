% =========================
% File: +krgui/buildUI_v7.m
% FULL UPDATED VERSION (adds Delete button)
% =========================
function app = buildUI_v7(app)
% buildUI_v7 Create windows + controls + axes. Store handles in app and guidata.

mainFig = figure( ...
    'Name','KR Call Detect v7 (plots)', ...
    'Color','w', ...
    'Units','normalized', ...
    'Position',[0.23 0.05 0.75 0.90], ...
    'CloseRequestFcn',@(src,evt) krgui.onCancel_v7(src));

listFig = figure( ...
    'Name','KR Call List', ...
    'Color','w', ...
    'Units','normalized', ...
    'Position',[0.02 0.15 0.20 0.78], ...
    'CloseRequestFcn',@(src,evt) krgui.onCancel_v7(mainFig));

% =========================
% LIST WINDOW UI
% =========================
tbl = uitable(listFig, ...
    'Units','normalized', ...
    'Position',[0.04 0.30 0.92 0.65], ...
    'ColumnEditable', false);

btnAdd = uicontrol(listFig,'Style','togglebutton', ...
    'Units','normalized','Position',[0.04 0.20 0.44 0.07], ...
    'String','Add','Value',0);

btnToggle = uicontrol(listFig,'Style','pushbutton', ...
    'Units','normalized','Position',[0.52 0.20 0.44 0.07], ...
    'String','Toggle');

btnDelete = uicontrol(listFig,'Style','pushbutton', ...
    'Units','normalized','Position',[0.04 0.12 0.92 0.06], ...
    'String','Delete', ...
    'FontWeight','bold');

txtSel = uicontrol(listFig,'Style','text', ...
    'Units','normalized','Position',[0.04 0.02 0.92 0.09], ...
    'String','Selected: (none)', ...
    'BackgroundColor','w', ...
    'HorizontalAlignment','left');

% =========================
% MAIN WINDOW UI (controls)
% =========================
uicontrol(mainFig,'Style','text','Units','normalized','Position',[0.01 0.955 0.32 0.03], ...
    'String','Acceptance threshold (dB above noise):', ...
    'BackgroundColor','w','HorizontalAlignment','left');

sld = uicontrol(mainFig,'Style','slider','Units','normalized','Position',[0.34 0.960 0.28 0.022], ...
    'Min',0,'Max',40,'Value',app.state.thrAboveNoise_dB);

txtThr = uicontrol(mainFig,'Style','text','Units','normalized','Position',[0.63 0.955 0.10 0.03], ...
    'String',sprintf('%.1f dB',app.state.thrAboveNoise_dB), ...
    'BackgroundColor','w');

btnOK = uicontrol(mainFig,'Style','pushbutton','Units','normalized','Position',[0.87 0.948 0.06 0.045], ...
    'String','OK','FontWeight','bold');

btnX  = uicontrol(mainFig,'Style','pushbutton','Units','normalized','Position',[0.94 0.948 0.05 0.045], ...
    'String','X');

% =========================
% MAIN WINDOW Axes
% =========================
axOverview = axes('Parent',mainFig,'Units','normalized','Position',[0.06 0.78 0.92 0.14]);
axCallSpec = axes('Parent',mainFig,'Units','normalized','Position',[0.06 0.52 0.44 0.22]);
axCallWave = axes('Parent',mainFig,'Units','normalized','Position',[0.54 0.52 0.44 0.22]);
axCtxSpec  = axes('Parent',mainFig,'Units','normalized','Position',[0.06 0.10 0.44 0.36]);
axCtxWave  = axes('Parent',mainFig,'Units','normalized','Position',[0.54 0.10 0.44 0.36]);

% =========================
% Store handles
% =========================
app.mainFig = mainFig;
app.listFig = listFig;

app.tbl = tbl;
app.btnAdd = btnAdd;
app.btnToggle = btnToggle;
app.btnDelete = btnDelete;
app.txtSel = txtSel;

app.sld = sld;
app.txtThr = txtThr;
app.btnOK = btnOK;
app.btnX = btnX;

app.axOverview = axOverview;
app.axCallSpec = axCallSpec;
app.axCallWave = axCallWave;
app.axCtxSpec  = axCtxSpec;
app.axCtxWave  = axCtxWave;

app.roi = struct('on',[],'off',[],'lisOn',[],'lisOff',[]);
app.specBounds = struct('on',[],'off',[]);

% Save app state to mainFig guidata (single source of truth)
guidata(mainFig, app);
end