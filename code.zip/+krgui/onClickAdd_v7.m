function onClickAdd_v7(mainFig)
app = guidata(mainFig);

if app.state.mode ~= "add" || ~isequal(gca, app.axOverview)
    return;
end

cp = get(app.axOverview,'CurrentPoint');
tClick = cp(1,1);
sClick = round(tClick*app.fs) + 1;
sClick = max(1, min(numel(app.env_dB), sClick));

thr = app.noiseFloor_dB + app.state.thrAboveNoise_dB;

on = sClick;
while on > 1 && app.env_dB(on) > thr
    on = on - 1;
end

off = sClick;
while off < numel(app.env_dB) && app.env_dB(off) > thr
    off = off + 1;
end

app.state.calls_on_fixed(end+1)  = on;
app.state.calls_off_fixed(end+1) = off;
app.state.manualKeep_fixed(end+1) = true;

[app.state.calls_on_fixed, ord] = sort(app.state.calls_on_fixed(:));
app.state.calls_off_fixed = app.state.calls_off_fixed(ord);
app.state.manualKeep_fixed = app.state.manualKeep_fixed(ord);

[app.state.calls_on_fixed, app.state.calls_off_fixed] = krgui.scrubBounds_v7(app.state.calls_on_fixed, app.state.calls_off_fixed, app.Nsamp);

app.state.autoKeep_fixed = krgui.computeAutoKeepMask_v7( ...
    app.env_dB, app.noiseFloor_dB, app.state.thrAboveNoise_dB, ...
    app.state.calls_on_fixed, app.state.calls_off_fixed);

[app.state.calls_on, app.state.calls_off, app.state.dispToFixed] = krgui.applyFilter_v7(app.state);

guidata(mainFig, app);
krgui.redrawAll_v7(mainFig);
end