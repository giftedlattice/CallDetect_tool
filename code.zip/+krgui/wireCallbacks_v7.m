% =========================
% File: +krgui/wireCallbacks_v7.m
% FULL UPDATED VERSION (wires Delete button)
% =========================
function wireCallbacks_v7(mainFig)
% wireCallbacks_v7 Attach callbacks. Callbacks operate by reading/writing guidata(mainFig).

app = guidata(mainFig);

% Main controls
app.sld.Callback       = @(~,~) krgui.onThrChanged_v7(mainFig);
app.btnOK.Callback     = @(~,~) krgui.onOK_v7(mainFig);
app.btnX.Callback      = @(~,~) krgui.onCancel_v7(mainFig);

% List controls
app.btnAdd.Callback    = @(~,~) krgui.onAddToggle_v7(mainFig);
app.btnToggle.Callback = @(~,~) krgui.onToggleManual_v7(mainFig);
app.btnDelete.Callback = @(~,~) krgui.onDeleteCall_v7(mainFig);

% Table selection
app.tbl.CellSelectionCallback = @(~,evt) krgui.onTableSelection_v7(mainFig, evt);

% Click-to-add (only active when Add toggle is on)
set(mainFig,'WindowButtonDownFcn',@(~,~) krgui.onClickAdd_v7(mainFig));

guidata(mainFig, app);
end